using System.Collections;
using UnityEngine;

public class PlayerMeleeAttack : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private WeaponStats weaponStats;
    [SerializeField] private Transform swordSlashTransform; // Slash visual + hitbox
    [SerializeField] private TrailRenderer _slashTrail;

    private SwordHitbox _swordHitbox;
    private Vector3 _baseSlashScale;
    private bool _isAttacking;
    private float _cooldownTimer;
    private float _baseTrailStartWidth;

    private void Awake()
    {
        if (swordSlashTransform != null)
        {
            _swordHitbox = swordSlashTransform.GetComponent<SwordHitbox>();
            _baseSlashScale = swordSlashTransform.localScale;

            // Ensure the slash starts disabled
            swordSlashTransform.gameObject.SetActive(false);
        }
        else
        {
            Debug.LogWarning("[PlayerMeleeAttack] SwordSlashTransform is not assigned.");
        }

        // Trail Setup
        if (_slashTrail != null)
        {
            // Store base start trail width
            _baseTrailStartWidth = _slashTrail.startWidth;

            // Ensure trail starts disabled
            _slashTrail.emitting = false;
            _slashTrail.Clear();
        }
    }

    private void Update()
    {
        HandleCooldown();
        HandleInput();
    }

    private void HandleCooldown()
    {
        if (_cooldownTimer > 0f)
            _cooldownTimer -= Time.deltaTime;
    }

    private void HandleInput()
    {
        if (weaponStats == null || swordSlashTransform == null)
            return;

        if (_isAttacking)
            return;

        if (_cooldownTimer > 0f)
            return;

        // Right mouse button pressed (Sword attack)
        if (InputManager.SwordWasPressed)
        {
            StartCoroutine(SwordAttackCoroutine());
        }
    }

    private IEnumerator SwordAttackCoroutine()
    {
        _isAttacking = true;

        // Set cooldown for the next attack
        _cooldownTimer = weaponStats.swordCooldown;

        // --- RANGE SETUP ---
        float rangeMultiplier = Mathf.Max(weaponStats.swordRangeMultiplier, 0.01f);
        Vector3 scaled = _baseSlashScale;
        scaled.x = _baseSlashScale.x * (1 + rangeMultiplier);
        swordSlashTransform.localScale = scaled;

        // --- DAMAGE SETUP ---
        if (_swordHitbox != null)
        {
            _swordHitbox.damage = weaponStats.swordDamage;
            _swordHitbox.CanHit = true;
        }
        // Initial Position
        float totalAngle = weaponStats.swordSweepAngle;
        float halfAngle = totalAngle * 0.5f;
        swordSlashTransform.localRotation = Quaternion.Euler(0f, 0f, -halfAngle);

        // Enable slash visual + collider
        swordSlashTransform.gameObject.SetActive(true);

        // Enable trail
        if (_slashTrail != null)
        {
            _slashTrail.Clear();       // clear previous trail
            _slashTrail.emitting = true;
        }

        // Sweep parameters
        float baseDuration = Mathf.Max(weaponStats.swordAttackDuration, 0.01f);
        float speedMultiplier = Mathf.Max(weaponStats.swordAttackDurationMultiplier, 0.01f);
        float duration = baseDuration * (1 + speedMultiplier);
        
        // Trail parameters
        if (_slashTrail != null)
            _slashTrail.startWidth = _baseTrailStartWidth * (1 + rangeMultiplier);


        float elapsed = 0f;

        while (elapsed < duration)
        {
            float t = elapsed / duration; // 0 -> 1
            float currentAngle = Mathf.Lerp(-halfAngle, +halfAngle, t);

            // Rotate the slash around Z in local space
            swordSlashTransform.localRotation = Quaternion.Euler(0f, 0f, currentAngle);

            elapsed += Time.deltaTime;
            yield return null;
        }

        // Optional: ensure final rotation
        swordSlashTransform.localRotation = Quaternion.Euler(0f, 0f, +halfAngle);

        // Disable hitbox
        if (_swordHitbox != null)
        {
            _swordHitbox.CanHit = false;
        }

        // Turn off trail emission (the tail will fade out naturally)
        if (_slashTrail != null)
        {
            _slashTrail.emitting = false;

            // Reset trail width back to base values
            _slashTrail.startWidth = _baseTrailStartWidth;
        }

        // Disable visual
        swordSlashTransform.gameObject.SetActive(false);

        // Reset local rotation and scale
        swordSlashTransform.localRotation = Quaternion.identity;
        swordSlashTransform.localScale = _baseSlashScale;

        _isAttacking = false;
    }

}

